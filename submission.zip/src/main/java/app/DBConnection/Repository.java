package app.DBConnection;

public class Repository {
}
