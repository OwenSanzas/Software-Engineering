package app.controller.utils;
import java.util.*;

public class DisplayUtils {
    public static void displayHome() {
        System.out.println("Welcome to the App!");
        System.out.println();
        System.out.println("login: ./app 'login <username> <password>'");
        System.out.println("join: ./app 'join'");
        System.out.println("create: ./app 'create username=\"<value>\" password=\"<value>\" name=\"<value>\" status=\"<value>\"'");
        System.out.println("show people: ./app 'people'");
    }

    public static void displayInvalidCommand(List<String> commandArgs) {
        System.out.println("Invalid command!");

        if (!commandArgs.isEmpty()) {
            // print the whole command
            System.out.println("Command: " + String.join(" ", commandArgs));
        }

    }
}