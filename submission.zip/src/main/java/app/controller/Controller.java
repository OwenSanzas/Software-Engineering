package app.controller;

import app.services.UserService;
import app.controller.utils.DisplayUtils;

import java.util.*;

public class Controller {

    private final UserService userService = new UserService();

    public void handleRequest(List<String> commandArgs) {
        if (commandArgs.isEmpty()) {
            DisplayUtils.displayHome();
            return;
        }

        String command = commandArgs.get(0).toLowerCase();

        switch (command) {
            case "home":
                DisplayUtils.displayHome();
                break;
            case "create":
                handleCreate(commandArgs);
                break;
            default:
                DisplayUtils.displayInvalidCommand(commandArgs);
        }
    }

    private void handleCreate(List<String> commandArgs) {
        String[] requiredFields = {"username", "password", "name", "status"};
        Map<String, String> fieldValues = new HashMap<>();

        for (int i = 1; i < commandArgs.size(); i++) {
            String[] parts = commandArgs.get(i).split("=", 2);
            if (parts.length == 2) {
                String field = parts[0].toLowerCase();
                String value = parts[1].replaceAll("^\"|\"$", ""); // 去掉前后的引号
                fieldValues.put(field, value);
            }
        }

        for (String field : requiredFields) {
            if (!fieldValues.containsKey(field)) {
                System.out.println("Missing required field: " + field);
                System.out.println("Usage: create username=\"<value>\" password=\"<value>\" name=\"<value>\" status=\"<value>\"");
                return;
            }
        }

        userService.createUser(
                fieldValues.get("username"),
                fieldValues.get("password"),
                fieldValues.get("name"),
                fieldValues.get("status")
        );
    }
}