package commands;

public class LoginCommand {
}
