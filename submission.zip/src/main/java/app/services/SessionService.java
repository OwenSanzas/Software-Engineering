package app.services;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import app.services.utils.*;

public class SessionService {

    private final Map<String, String> sessions = new HashMap<>();

    // 创建新的 session，返回自定义的 session token
    public String createSession(String username) {
        String sessionToken = ShortIdGenerator.generateShortId();
        sessions.put(sessionToken, username);
        return sessionToken;
    }

}
