package app.services;

import app.models.Person;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class UserService {

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public void createUser(String username, String password, String name, String status) {
        Person newUser = new Person(username, password, name, status, LocalDateTime.now());
        System.out.println("[account created]");
        System.out.println("Person");
        System.out.println("------");
        System.out.println("name: " + newUser.getName());
        System.out.println("username: " + newUser.getUsername());
        System.out.println("status: " + newUser.getStatus());
        System.out.println("updated: " + newUser.getUpdated());
    }

}