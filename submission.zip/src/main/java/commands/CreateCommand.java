package commands;

public class CreateCommand {
}
