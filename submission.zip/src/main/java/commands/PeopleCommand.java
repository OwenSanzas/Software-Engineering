package commands;

public class PeopleCommand {
}
